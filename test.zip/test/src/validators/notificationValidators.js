import { body, param } from 'express-validator';

export const createNotificationValidation = [
  body('userId').isInt({ min: 1 }).withMessage('Valid user ID is required'),
  body('title').notEmpty().withMessage('Title is required'),
  body('message').notEmpty().withMessage('Message is required'),
];

export const markAsReadValidation = [
  param('id').isInt({ min: 1 }).withMessage('Valid notification ID is required'),
];

export const deleteNotificationValidation = [
  param('id').isInt({ min: 1 }).withMessage('Valid notification ID is required'),
];
