export const validateCSVRow = (row, rowIndex) => {
  const errors = [];

  if (!row.name || row.name.trim() === '') {
    errors.push(`Row ${rowIndex}: Name is required`);
  }

  if (!row.email || row.email.trim() === '') {
    errors.push(`Row ${rowIndex}: Email is required`);
  } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(row.email)) {
    errors.push(`Row ${rowIndex}: Invalid email format`);
  }

  if (!row.password || row.password.trim() === '') {
    errors.push(`Row ${rowIndex}: Password is required`);
  } else if (row.password.length < 6) {
    errors.push(`Row ${rowIndex}: Password must be at least 6 characters`);
  }

  const validRoles = ['admin', 'user'];
  if (row.role && !validRoles.includes(row.role.toLowerCase())) {
    errors.push(`Row ${rowIndex}: Role must be 'admin' or 'user'`);
  }

  return errors;
};
