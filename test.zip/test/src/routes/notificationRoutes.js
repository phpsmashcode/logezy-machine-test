import { Router } from 'express';
import { create, list, markRead, remove } from '../controllers/notificationController.js';
import {
  createNotificationValidation,
  markAsReadValidation,
  deleteNotificationValidation,
} from '../validators/notificationValidators.js';
import { authenticate } from '../middleware/auth.js';

const router = Router();

router.post('/', authenticate, createNotificationValidation, create);
router.get('/', authenticate, list);
router.patch('/:id/read', authenticate, markAsReadValidation, markRead);
router.delete('/:id', authenticate, deleteNotificationValidation, remove);

export default router;
