import { Router } from 'express';
import { upload, uploadCSV, getImportStatus } from '../controllers/csvImportController.js';
import { authenticate, authorizeAdmin } from '../middleware/auth.js';

const router = Router();

// POST /csv-import/import - Upload and start background CSV import
router.post('/import', authenticate, authorizeAdmin, upload.single('file'), uploadCSV);

// GET /csv-import/status/:jobId - Check import job status
router.get('/status/:jobId', authenticate, getImportStatus);

export default router;
