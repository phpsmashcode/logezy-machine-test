import fs from 'fs';
import csv from 'csv-parser';
import bcrypt from 'bcryptjs';
import prisma from '../config/prisma.js';
import { validateCSVRow } from '../validators/csvValidators.js';

const SALT_ROUNDS = 10;

export const parseCSVFile = (filePath) => {
  return new Promise((resolve, reject) => {
    const rows = [];
    fs.createReadStream(filePath)
      .pipe(csv())
      .on('data', (row) => rows.push(row))
      .on('end', () => resolve(rows))
      .on('error', (error) => reject(error));
  });
};

export const validateCSVRows = (rows) => {
  const validRows = [];
  const invalidRows = [];

  rows.forEach((row, index) => {
    const rowIndex = index + 2; // +2 because headers are row 1
    const errors = validateCSVRow(row, rowIndex);

    if (errors.length > 0) {
      invalidRows.push({ rowIndex, data: row, errors });
    } else {
      validRows.push(row);
    }
  });

  return { validRows, invalidRows };
};

export const bulkInsertUsers = async (rows) => {
  const results = {
    successful: [],
    failed: [],
  };

  for (const row of rows) {
    try {
      const existing = await prisma.user.findUnique({
        where: { email: row.email },
      });

      if (existing) {
        results.failed.push({
          email: row.email,
          error: 'Email already exists',
        });
        continue;
      }

      const hashed = await bcrypt.hash(row.password, SALT_ROUNDS);
      const user = await prisma.user.create({
        data: {
          name: row.name,
          email: row.email,
          password: hashed,
          role: (row.role || 'user').toLowerCase(),
        },
        select: { id: true, name: true, email: true, role: true, createdAt: true },
      });

      results.successful.push(user);
    } catch (error) {
      results.failed.push({
        email: row.email,
        error: error.message,
      });
    }
  }

  return results;
};

export const processCSVImport = async (filePath) => {
  try {
    console.log(`[CSV IMPORT] Parsing file: ${filePath}`);
    const rows = await parseCSVFile(filePath);
    console.log(`[CSV IMPORT] Parsed ${rows.length} rows from CSV`);

    const { validRows, invalidRows } = validateCSVRows(rows);
    console.log(`[CSV IMPORT] Valid rows: ${validRows.length}, Invalid rows: ${invalidRows.length}`);

    let insertResults = { successful: [], failed: [] };
    if (validRows.length > 0) {
      console.log(`[CSV IMPORT] Inserting ${validRows.length} users into database`);
      insertResults = await bulkInsertUsers(validRows);
    }

    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
    }

    const summary = {
      totalRows: rows.length,
      validRows: validRows.length,
      invalidRows: invalidRows.length,
      inserted: insertResults.successful.length,
      duplicateOrFailed: insertResults.failed.length,
      errors: invalidRows,
      failedInserts: insertResults.failed,
      timestamp: new Date().toISOString(),
    };

    console.log(`[CSV IMPORT] Import complete:`, summary);
    return summary;
  } catch (error) {
    console.error(`[CSV IMPORT] Error processing CSV:`, error);
    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
    }
    throw error;
  }
};
