import prisma from '../config/prisma.js';

export const createNotification = async ({ userId, title, message }) => {
  const notification = await prisma.notification.create({
    data: { userId, title, message },
    select: { id: true, userId: true, title: true, message: true, isRead: true, createdAt: true },
  });
  return notification;
};

export const listNotifications = async (userId, filters = {}) => {
  const where = { userId };
  
  if (filters.isRead !== undefined) {
    where.isRead = filters.isRead === 'true' || filters.isRead === true;
  }

  const notifications = await prisma.notification.findMany({
    where,
    orderBy: { createdAt: 'desc' },
    select: { id: true, userId: true, title: true, message: true, isRead: true, createdAt: true },
  });
  
  return notifications;
};

export const markAsRead = async (notificationId, userId) => {
  const notification = await prisma.notification.findFirst({
    where: { id: notificationId, userId },
  });

  if (!notification) {
    const error = new Error('Notification not found');
    error.statusCode = 404;
    throw error;
  }

  const updated = await prisma.notification.update({
    where: { id: notificationId },
    data: { isRead: true },
    select: { id: true, userId: true, title: true, message: true, isRead: true, createdAt: true },
  });

  return updated;
};

export const deleteNotification = async (notificationId, userId) => {
  const notification = await prisma.notification.findFirst({
    where: { id: notificationId, userId },
  });

  if (!notification) {
    const error = new Error('Notification not found');
    error.statusCode = 404;
    throw error;
  }

  await prisma.notification.delete({
    where: { id: notificationId },
  });

  return { message: 'Notification deleted successfully' };
};

export const deleteOldNotifications = async () => {
  const thirtyDaysAgo = new Date();
  thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

  console.log(`[CRON DEBUG] Current time: ${new Date().toISOString()}`);
  console.log(`[CRON DEBUG] Cutoff time (30 days ago): ${thirtyDaysAgo.toISOString()}`);
  console.log(`[CRON DEBUG] Deleting notifications with createdAt < ${thirtyDaysAgo.toISOString()}`);

  const result = await prisma.notification.deleteMany({
    where: {
      createdAt: {
        lt: thirtyDaysAgo,
      },
    },
  });

  console.log(`[CRON DEBUG] Deleted ${result.count} notifications`);
  return { deletedCount: result.count };
};
