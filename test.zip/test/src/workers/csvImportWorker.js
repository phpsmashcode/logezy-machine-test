import { Worker } from 'bullmq';
import fs from 'fs';
import csv from 'csv-parser';
import bcrypt from 'bcryptjs';
import prisma from '../config/prisma.js';

const SALT_ROUNDS = 10;
const BATCH_SIZE = 100;

const redisConnection = {
  host: process.env.REDIS_HOST || 'localhost',
  port: process.env.REDIS_PORT || 6379,
};

const worker = new Worker(
  'csv-import',
  async (job) => {
    console.log(`[WORKER] Processing job ${job.id}: ${job.data.filePath}`);
    
    const results = [];
    const errors = [];
    let batch = [];
    let rowIndex = 1;
    let totalRows = 0;

    return new Promise((resolve, reject) => {
      fs.createReadStream(job.data.filePath)
        .pipe(csv())
        .on('data', async (row) => {
          rowIndex++;
          totalRows++;

          // Validate row
          const validationErrors = validateRow(row, rowIndex);
          if (validationErrors.length > 0) {
            errors.push({ rowIndex, email: row.email, validationErrors });
            return;
          }

          // Hash password
          const hashedPassword = await bcrypt.hash(row.password, SALT_ROUNDS);

          batch.push({
            name: row.name,
            email: row.email,
            password: hashedPassword,
            role: (row.role || 'user').toLowerCase(),
          });

          // Insert batch when size reaches BATCH_SIZE
          if (batch.length === BATCH_SIZE) {
            await insertBatch(batch, results, errors);
            batch = [];
            
            // Update progress after batch insertion (non-blocking)
            job.updateProgress(Math.min(100, Math.round((results.length / totalRows) * 100))).catch(() => {
              // Silently ignore progress update failures
            });
          }
        })
        .on('end', async () => {
          try {
            // Insert remaining rows
            if (batch.length > 0) {
              await insertBatch(batch, results, errors);
            }

            // Update final progress
            job.updateProgress(100).catch(() => {
              // Silently ignore progress update failures
            });

            // Clean up file
            if (fs.existsSync(job.data.filePath)) {
              fs.unlinkSync(job.data.filePath);
            }

            console.log(
              `[WORKER] Job ${job.id} completed: ${results.length} inserted, ${errors.length} failed`
            );

            resolve({
              totalRows,
              insertedCount: results.length,
              failedCount: errors.length,
              errors,
            });
          } catch (error) {
            reject(error);
          }
        })
        .on('error', (error) => {
          console.error(`[WORKER] Error processing CSV:`, error);
          if (fs.existsSync(job.data.filePath)) {
            fs.unlinkSync(job.data.filePath);
          }
          reject(error);
        });
    });
  },
  { connection: redisConnection }
);

const validateRow = (row, rowIndex) => {
  const errors = [];

  if (!row.name || row.name.trim() === '') {
    errors.push('Name is required');
  }

  if (!row.email || row.email.trim() === '') {
    errors.push('Email is required');
  } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(row.email)) {
    errors.push('Invalid email format');
  }

  if (!row.password || row.password.trim() === '') {
    errors.push('Password is required');
  } else if (row.password.length < 6) {
    errors.push('Password must be at least 6 characters');
  }

  const validRoles = ['admin', 'user'];
  if (row.role && !validRoles.includes(row.role.toLowerCase())) {
    errors.push('Role must be admin or user');
  }

  return errors;
};

const insertBatch = async (batch, results, errors) => {
  try {
    const created = await prisma.user.createMany({
      data: batch,
      skipDuplicates: true, // Skip duplicates silently
    });

    results.push(...batch);
    console.log(`[WORKER] Inserted batch: ${created.count} new, ${batch.length - created.count} skipped (duplicates)`);
  } catch (error) {
    console.error(`[WORKER] Batch insert error:`, error.message);
    errors.push({ batch: true, error: error.message });
  }
};

worker.on('completed', (job) => {
  console.log(`[WORKER] Job ${job.id} completed successfully`);
});

worker.on('failed', (job, err) => {
  console.error(`[WORKER] Job ${job.id} failed:`, err.message);
});

export default worker;
