import multer from 'multer';
import path from 'path';
import fs from 'fs';
import csvImportQueue from '../utils/queue.js';

// Ensure uploads directory exists
const uploadsDir = 'uploads';
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

// Configure multer for CSV uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/');
  },
  filename: (req, file, cb) => {
    const timestamp = Date.now();
    cb(null, `${timestamp}-${file.originalname}`);
  },
});

const fileFilter = (req, file, cb) => {
  if (file.mimetype === 'text/csv' || file.originalname.endsWith('.csv')) {
    cb(null, true);
  } else {
    cb(new Error('Only CSV files are allowed'), false);
  }
};

export const upload = multer({ storage, fileFilter });

export const uploadCSV = async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ message: 'No CSV file provided' });
    }

    const filePath = req.file.path;

    // Add job to BullMQ queue
    const job = await csvImportQueue.add(
      'import',
      { filePath },
      {
        attempts: 3,
        backoff: {
          type: 'exponential',
          delay: 2000,
        },
        removeOnComplete: {
          age: 3600, // Keep in Redis for 1 hour after completion
        },
      }
    );

    console.log(`[CSV IMPORT] Job ${job.id} queued for async processing`);

    res.status(202).json({
      message: 'CSV import started in background',
      jobId: job.id,
      status: 'processing',
      file: req.file.originalname,
    });
  } catch (error) {
    console.error('[CSV IMPORT] Upload error:', error);
    res.status(500).json({ message: error.message });
  }
};

export const getImportStatus = async (req, res) => {
  try {
    const { jobId } = req.params;

    if (!jobId) {
      return res.status(400).json({ message: 'Job ID is required' });
    }

    // Get job from queue
    const job = await csvImportQueue.getJob(jobId);

    if (!job) {
      return res.status(404).json({ message: 'Job not found' });
    }

    const state = await job.getState();
    const progressValue = typeof job._progress === 'number' ? job._progress : 0;
    const data = job.data;
    const result = job.returnvalue;

    res.json({
      jobId: job.id,
      status: state,
      progress: progressValue,
      result,
      createdAt: job.timestamp,
    });
  } catch (error) {
    console.error('[CSV IMPORT] Status error:', error);
    res.status(500).json({ message: error.message });
  }
};
