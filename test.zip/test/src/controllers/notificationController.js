import {
  createNotification,
  listNotifications,
  markAsRead,
  deleteNotification,
} from '../services/notificationService.js';
import { handleValidation } from '../utils/validation.js';

export const create = [
  handleValidation,
  async (req, res) => {
    try {
      const { userId, title, message } = req.body;
      const notification = await createNotification({ userId, title, message });
      res.status(201).json({ message: 'Notification created successfully', notification });
    } catch (error) {
      res.status(error.statusCode || 500).json({ message: error.message });
    }
  },
];

export const list = async (req, res) => {
  try {
    const userId = req.user.userId;
    const { isRead } = req.query;
    const notifications = await listNotifications(userId, { isRead });
    res.json({ notifications });
  } catch (error) {
    res.status(error.statusCode || 500).json({ message: error.message });
  }
};

export const markRead = [
  handleValidation,
  async (req, res) => {
    try {
      const notificationId = parseInt(req.params.id);
      const userId = req.user.userId;
      const notification = await markAsRead(notificationId, userId);
      res.json({ message: 'Notification marked as read', notification });
    } catch (error) {
      res.status(error.statusCode || 500).json({ message: error.message });
    }
  },
];

export const remove = [
  handleValidation,
  async (req, res) => {
    try {
      const notificationId = parseInt(req.params.id);
      const userId = req.user.userId;
      const result = await deleteNotification(notificationId, userId);
      res.json(result);
    } catch (error) {
      res.status(error.statusCode || 500).json({ message: error.message });
    }
  },
];
