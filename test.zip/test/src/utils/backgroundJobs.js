// Simple job queue for background processing
export const importJobQueue = [];

export const startBackgroundJobProcessor = () => {
  console.log('[BACKGROUND JOBS] Background job processor started');
};
