import { Queue } from 'bullmq';
import { createClient } from 'redis';

const redisConnection = {
  host: process.env.REDIS_HOST || 'localhost',
  port: process.env.REDIS_PORT || 6379,
};

const csvImportQueue = new Queue('csv-import', { connection: redisConnection });

export default csvImportQueue;
