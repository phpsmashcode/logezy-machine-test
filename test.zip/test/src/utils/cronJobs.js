import cron from 'node-cron';
import { deleteOldNotifications } from '../services/notificationService.js';

export const startNotificationRetentionCron = () => {
  // Run daily at 2:00 AM
  // */2 * * * * (every 2 minutes for testing)
  cron.schedule('0 2 * * *', async () => {
    try {
      console.log('[CRON] Running notification retention cron job');
      const result = await deleteOldNotifications();
      console.log(`[CRON] Deleted ${result.deletedCount} old notifications`);
    } catch (error) {
      console.error('[CRON] Error in notification retention cron job:', error);
    }
  });
  
  console.log('[CRON] Notification retention cron job scheduled (daily at 2:00 AM)');
};
